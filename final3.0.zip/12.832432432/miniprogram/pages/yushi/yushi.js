// pages/yushi/yushi.js
var url2 = "https://zh1024.goho.co/usb";
var url1 = "https://zh1024.hsk.top/usb";
var last = 0;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    inter: '',
    test: ["", "", "", "", "", "", "", "", "", "", "", ""]
  },



  gotopaidui() {
    wx.navigateTo({
      url: '/pages/indexe/indexe',
    })
  },
	gotoliebiao() {
    wx.navigateTo({
      url: '/pages/liebiao/liebiao',
    })
  },
  startInterval: function () {
    /**
     * 启动定时器
     */
		var that = this;
		
    that.data.inter = setInterval(
      function () {
        // TODO 你需要无限循环执行的任务
        
				
        wx.request({

          url: url2,
          data: {
            ID: "840d8ea61b81",
            DATA: "@"
          },
          method: "POST",
          header: {
            'content-type': 'application/json'
          },
          success: (result) => {
            let t = result.data.time;
            console.log("响应时间：");
            console.log(t);
            if (t > 4) {
              
             // wx.showToast({
             //   title: '请求失败，请刷新！',
              //  icon: 'error',
              //  duration: 2000 //持续的时间
             // });
              console.log("请求失败");
              let tmp = url1;
              url1 = url2;
              url2 = tmp;
              return;
            }
            
            console.log(result.data);
						var res = [17];
						var sum = 0;
						var test = new Array(16);
            for (let i = 1; i <= 16; i++) {
							res[i] = result.data.data[i];
							sum += res[i];
              if (res[i] == 1) {
                test[i - 1] = "使用中"
              } else if (res[i] == 0) {
                test[i - 1] = ""
              }
						};
						switch(last-sum){
							//删除数据
							
						}
						for (let i = 1; i <= 16; i++) {
							last = 0;
							last += res[i];
						}
            that.setData({
              "test": test
            });
          }
        })
      }, 500);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    setTimeout(() => {
      this.startInterval(this.data.inter);
    }, 500);
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    wx.showLoading({
      title: '刷新中',
    })
    wx.request({
      url: url2,
      data: {
        ID: "840d8ea61b81",
        DATA: "@"
      },
      method: "POST",
      header: {
        'content-type': 'application/json'
      },
      success: (result) => {
        let t = result.data.time;
        console.log("响应时间：");
        console.log(t);
        if (t > 4) {
          wx.showToast({
            title: '请求失败，请刷新！',
            icon: 'error',
            duration: 2000
          })
           wx.hideLoading();
          console.log("请求失败");
          let tmp = url1;
          url1 = url2;
          url2 = tmp;
          return;
        }
        wx.hideLoading();
        console.log(result.data);
        var res = [17];
        var test = new Array(16);
        for (let i = 1; i <= 16; i++) {
          res[i] = result.data.data[i];
          if (res[i] == 1) {
            test[i - 1] = "使用中"
          } else if (res[i] == 0) {
            test[i - 1] = ""
          }
        };
        this.setData({
          "test": test
        });
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {


  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },


  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    /**
     * 结束定时器
     */
    clearInterval(this.data.inter)
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    wx.showLoading({
      title: '刷新中',
    })
    wx.request({
      url: url2,
      data: {
        ID: "840d8ea61b81",
        DATA: "@"
      },
      method: "POST",
      header: {
        'content-type': 'application/json'
      },
      success: (result) => {
        let t = result.data.time;
        console.log("响应时间：");
        console.log(t);
        if (t > 4) {
          wx.showToast({
            title: '请求失败，请刷新！',
            icon: 'error',
            duration: 2000 //持续的时间
          })
          // wx.hideLoading();
          wx.stopPullDownRefresh();
          console.log("请求失败");
          let tmp = url1;
          url1 = url2;
          url2 = tmp;
          return;
        }
        wx.hideLoading();
        wx.stopPullDownRefresh();
        console.log(result.data);
        var res = [17];
        var test = new Array(16);
        for (let i = 1; i <= 16; i++) {
          res[i] = result.data.data[i];
          if (res[i] == 1) {
            test[i - 1] = "使用中"
          } else if (res[i] == 0) {
            test[i - 1] = ""
          }
        };
        this.setData({
          "test": test
        });
      }
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})