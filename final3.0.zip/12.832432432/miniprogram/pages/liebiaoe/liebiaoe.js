// pages/liebiao/liebiao.js
Page({
 
	/**
	 * 页面的初始数据
	 */
	data: {
			openie:[],
			lianxi:[]
	},
	//刷新用户信息
	shuaxin(){
			let that = this
			//获取排号
			wx.cloud.database().collection('lianxi').get({
					success:function(res){
							let xuhao = res.data
							console.log('用户排号：',xuhao)
							that.setData({
									lianxi:xuhao
							})
					}
			})
			
			//获取用户信息
			 wx.cloud.database().collection('openie').get({
					success:function(res){
							console.log('用户信息获取成功',res.data)
							that.setData({
									openie:res.data
							})
					},
					fail:function(rex){
							console.log('用户信息获取失败',res)
					}
			})

	},
	
	//刷新排号
	// paihao(){
	//     wx.cloud.database().collection('lianxi').where({
	//     }).get().then(res => {
	//         let zuixinpaihao = res.data.length
	//         //获取data中的信息总数
	//         let bianhao = res.data[zuixinpaihao-1]
	//         console.log(res)
	//         console.log('获取排号信息成功',bianhao.paihao)
	//         console.log('获取当前排号时的时间',bianhao.key)
	//         console.log('获取当前排号时的_openid',bianhao._openid)
	//         this.setData({
	//             zuixinbianhao:bianhao.paihao,
	//             DQSJ:bianhao.key
	//         })
	//         //因为是从零开始的数组，所以数组的paihao数值-1就是数组的排列编号
					
	//     })
	//     .catch(res => {
	//         console.log('获取排号信息失败',res)
	//     })
	// },

	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad(options) {
			
			

			// wx.cloud.database().collection('openid').where({
			// }).get().then(res => {
			//     let zuixinpaihao = res.data.length
			//         //获取data中的信息总数
			//         let bianhao = res.data[zuixinpaihao-1]
			//     console.log('获取openid中的数据:',res)
			//     this.setData({
			//         name:bianhao.name,
			//         path:bianhao.path
			//     })
			// })
	
	
	},

	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady() {

	},

	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow() {
			wx.cloud.database().collection('lianxi').where({
			}).get().then(res => {
					let zuixinpaihao = res.data.length
					//获取data中的信息总数
					let bianhao = res.data[zuixinpaihao-1]
					console.log(res)
					console.log('获取排号信息成功',bianhao.paihao)
					console.log('获取当前排号时的时间',bianhao.key)
					console.log('获取当前排号时的_openid',bianhao._openid)
					this.setData({
							zuixinbianhao:bianhao.paihao,
							DQSJ:bianhao.key
					})
					//因为是从零开始的数组，所以数组的paihao数值-1就是数组的排列编号
					
			})
			.catch(res => {
					console.log('获取排号信息失败',res)
			})

			 this.shuaxin()
			
	},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide() {

	},

	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload() {

	},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh() {

	},

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom() {

	},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage() {

	}
})