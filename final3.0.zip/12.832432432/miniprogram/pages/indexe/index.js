// pages/index/index.js
let Deid=""
// 获取需要删除ID

Page({
	/**
	 * 页面的初始数据
	 */
	data: {
			named:"昵称",
			path:"/images/touxiang(moren).png",
			issshow:false,
		  isshow:true,
		  show:true
	},




	gotoliebiao() {
    wx.navigateTo({
      url: '/pages/liebiaoe/liebiaoe',
    })
  },
	//点击进行编号
	paihao(){
			 let that = this
			if (that.data.named=="昵称") {
					wx.showToast({
						title: '您还未登录！',
						icon:"none"
					})
			}else{
			let isshow
			let paihao
			console.log("正在排号")
			let key = this.getshijian()
			//this.的含义是指此index.js中所有的内置函数以及自己定义的方法（此js文件中所有能过调用的对象）
			console.log(key)
			//查询当前已经排号到多少位
			wx.cloud.database().collection('lianxi').where({
					key:key,
			}).count().then(res =>{
					console.log('查询成功',res)
					paihao = res.total+1
			wx.cloud.database().collection('lianxi').add({
					data:{
							key:key,
							paihao:paihao,
							
					}
			}).then(res =>{
					console.log('添加成功',res)
					this.getchakanpaihao()

					wx.cloud.database().collection('lianxi').where({
					}).get().then(res => {
							let zuixinpaihao = res.data.length
							//获取data中的信息总数
							let bianhao = res.data[zuixinpaihao-1]
							console.log(res)
							console.log('获取排号信息成功',bianhao.paihao)
							console.log('获取当前排号时的时间',bianhao.key)
							console.log('获取当前排号时的_openid',bianhao._openid)
							//
							// wx.cloud.database().collection('openid').add({
							//     data:{
							//         openid:bianhao._openid
							//     }
							// })
								//
							this.setData({
									zuixinbianhao:bianhao.paihao,
									DQSJ:bianhao.key,
									isshow:false,
									issshow:true
							})
					})
			}).catch(res =>{
					console.log('添加失败',res)
			})
			}).catch(res=>{
					console.log('查询失败',res)
			})
			}

	},
	//授权登录
	denglu(){
		this.setData({
					
					issshow:true,
					
					
		})
			let that = this
			
		/* 	if (that.data.named=="昵称") {
					//wx.showToast({
					//	title: '您还未登录！',
					//	icon:"none"
				//	})
				wx.getUserProfile({
					desc: '正在获取',
					success:function(res){
							console.log('获取成功: ',res)
						//添加用户信息到openid数据库
								wx.cloud.database().collection('openid').add({
										data:{
												name:res.userInfo.nickName,
												path:res.userInfo.avatarUrl
										}
								})
	
								//显示用户信息到首页
							/*that.setData({
									named:res.userInfo.nickName,
									path:res.userInfo.avatarUrl,
									show:false
							})*/
	
						//   
				/*/	},
					fail:function(err){
							console.log("获取失败：",err)
					}
				})
			}else{ */
				wx.cloud.database().collection('openie').add({
					data:{
							name:Deid,
							//path:that.data.path
					}
			})
			that.setData({
				
				show:false
		})
			
			
			// return that.setData
	},
	//获取当前年月日
	getshijian(){
			
			let date = new Date()
			let year = date.getFullYear()
			//因为getMonth()获取到的月份是从0开始的所以要加1
			let month = date.getMonth()+1
			let day = date.getDate()
			// let Hour = date.getHours()
			// let fen = date.getMinutes()
			// let miao = date.getSeconds()
			// let XQ = date.getDay()
			let key=year+'-'+month+'-'+day
			return key
			// console.log(key)
	},
	//查看自己的排号信息
	getchakanpaihao(){
			wx.cloud.database().collection('openid').where({
			}).get().then(res => {
					let zuixinpaihao = res.data.length
					//获取data中的信息总数
					let bianhao = res.data[zuixinpaihao-1]
					// console.log('获取排号信息成功',bianhao.paihao)
					// console.log('获取当前排号时的时间',bianhao.key)
					// console.log('获取当前排号时的id',bianhao._id)
					// console.log('获取当前排号时的时间',res)
					this.setData({
							zuixinbianhao:bianhao.paihao,
							DQSJ:bianhao.key,
					})
					//因为是从零开始的数组，所以数组的paihao数值-1就是数组的排列编号
			})
			.catch(res => {
					console.log('获取排号信息失败',res)
			})

	},
	//取消预约
  quxiaoyuyue(){
		this.setData({
					
			issshow:false,
			show:true
			
			
	})
		let that = this
		
    wx.cloud.database().collection('openie')
    .where({name:Deid
		})
		.remove()

  },
  //})
  //.catch(res => {
  //    console.log('获取排号信息失败',res)
 // })


    //.get().then(res => {
				//let zuixinpaihao = res.data.length
				//获取data中的信息总数
				//let bianhao = res.data[zuixinpaihao-2]
				// console.log('获取排号信息成功',bianhao.paihao)
				// console.log('获取当前排号时的时间',bianhao.key)
				// console.log('获取当前排号时的id',bianhao._id)
				// console.log('获取当前排号时的时间',res)
				//this.setData({
				//		zuixinbianhao:bianhao.paihao,
				//		DQSJ:bianhao.key,
				//		issshow:false,
				//		isshow:true
						
			//	})
				//因为是从零开始的数组，所以数组的paihao数值-1就是数组的排列编号
		
delData(e){
	Deid=e.detail.value
	},
	// 删除数据
	deleteDdata(){
	db.doc(Deid).remove({
		success(res){
			console.log("删除数据成功",res.data)
		},
		fail(res){
	console.log("删除失败",res.data)
		}
	})
	},

	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad(options) {
			this.getchakanpaihao()
	},

	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady() {

	},

	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow(){

	},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide() {

	},

	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload() {

	},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh() {

	},

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom() {

	},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage() {

	}
})