Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  goBack() {
    wx.navigateBack({
      delta: 2
    });
  },

});
